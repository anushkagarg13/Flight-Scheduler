# Artificial-Intelligence-in-Flight-Scheduling

The whole project is pushed inside the repository. 
Kindly, open the project in your IDE (preferably Eclipse) for checking out the results.
The main file is Multithreading.java
Rest are created for things learnt while making the project.
